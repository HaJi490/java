package exam;

class Item {
	private String name; // 제품명
	private double price;// 제품가격
	private int stockQuantity; // 재고량

	// 생성자
	public Item(String name, double price, int stockQuantity) {
		this.name = name;
		this.price = price;
		this.stockQuantity = stockQuantity;
	}

	void reduceStock(int quantity) {
		// 판매시 재고감소 메소드
		System.out.println( stockQuantity - quantity );
	}

	void increaseStock(int quantity) {
		System.out.println();
	}

	public void show() {
		// name = ***, price=*** 등으로출력
		System.out.println("name = " + name + "\t price =" + price);
	}

	public String toString() {
		return "name = " + name;
	}
}

class Customer {
	private String cname;
	private String city;
	private int age;
	
	//생성자
	public Customer(String cname, String city, int age) {	
	}
	
	//메서드
	public void show() {
		// name = ***, city = *** 등으로출력
		System.out.println("name = " + cname + "\t city = " + city + "\t age = " + age);  
	}
}

class Order {
	private Customer customer; // 고객명
	private Item[] items; // 주문제품들
	private int[] quantities;// 주문제품수량들
	private String[] orderDates;// 주문일자들
	private int count = 0; // 배열인덱스
	
	//생성자
	public Order(Customer customer, Item[] items, int[] quantities, String[] orderDates, int count) { //생성자를 다 생성해야하나
		this.customer = customer;
		this.items = items;
		this.quantities = quantities;
		this.orderDates = orderDates;
		this.count = count;
		
	}

	public Order(Customer boy) {
		// TODO Auto-generated constructor stub
	}

	void addItem(Item items, int orderNumber) {
		System.out.println("주문제품 ="+ items + "주문갯수 =" + orderNumber);
	}

	double calculateTotal() {
		return 0.0;
	}

	void printOrderSummary() {
	}

}

public class ExamB1 {
	public static void main(String[] args) {
		 // 아이템생성
		Item laptop = new Item("노트북", 1200.00, 10); 
		Item tshirt = new Item("티셔츠", 20.00, 50); 
		
		laptop.show();
		tshirt.show();
		
		// 고객생성
		Customer boy = new Customer("홍길동", "부산", 21); 
		Customer girl = new Customer("계백", "양산", 22); 

		boy.show();
		girl.show();
		
		// 주문생성
 		Order order1 = new Order(boy); //boy : Customer클래스의 참조변수
		order1.addItem(laptop, 1); 
		order1.addItem(tshirt, 2);
		
	}

}
