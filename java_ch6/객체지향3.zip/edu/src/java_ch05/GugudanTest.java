package java_ch05;

public class GugudanTest {
	

	public static void main(String[] args) {
		Gugudan ggd = new Gugudan();
		
		
		//ggd.printVertical(); // 1. printVertical 메소드를 불러와서 진행
		
		//ggd.printHorizontal();
		
		ggd.printColumn(3);
	}
}